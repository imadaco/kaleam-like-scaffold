import React, { useRef, useState } from 'react'
import API from '../api'

// Simple SVG path drawing editor (pointer events)
export default function Editor({ user }) {
  const [strokes, setStrokes] = useState([])
  const [current, setCurrent] = useState(null)
  const [strokeWidth, setStrokeWidth] = useState(12)
  const [strokeColor, setStrokeColor] = useState('#000000')
  const svgRef = useRef()
  const [projectName, setProjectName] = useState('Untitled')

  function pointerDown(e) {
    const pt = getPoint(e)
    setCurrent({ points: [pt], width: strokeWidth, color: strokeColor })
    window.addEventListener('pointermove', pointerMove)
    window.addEventListener('pointerup', pointerUp)
  }

  function pointerMove(e) {
    e.preventDefault()
    const pt = getPoint(e)
    setCurrent((c) => (c ? { ...c, points: [...c.points, pt] } : c))
  }

  function pointerUp() {
    if (current && current.points.length > 0) {
      const d = pointsToSvgPath(current.points)
      setStrokes((s) => [...s, { d, width: current.width, color: current.color }])
    }
    setCurrent(null)
    window.removeEventListener('pointermove', pointerMove)
    window.removeEventListener('pointerup', pointerUp)
  }

  function getPoint(e) {
    const svg = svgRef.current
    const rect = svg.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top
    return { x, y }
  }

  function pointsToSvgPath(points) {
    if (!points.length) return ''
    let d = `M ${points[0].x} ${points[0].y}`
    for (let i = 1; i < points.length - 1; i++) {
      const midX = (points[i].x + points[i + 1].x) / 2
      const midY = (points[i].y + points[i + 1].y) / 2
      d += ` Q ${points[i].x} ${points[i].y} ${midX} ${midY}`
    }
    const last = points[points.length - 1]
    d += ` L ${last.x} ${last.y}`
    return d
  }

  function exportSVG() {
    const svgEl = svgRef.current.cloneNode(true)
    svgEl.setAttribute('xmlns', 'http://www.w3.org/2000/svg')
    const serializer = new XMLSerializer()
    const svgStr = serializer.serializeToString(svgEl)
    const blob = new Blob([svgStr], { type: 'image/svg+xml;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${projectName.replace(/\s+/g, '_')}.svg`
    a.click()
    URL.revokeObjectURL(url)
  }

  async function saveProject() {
    const svgEl = svgRef.current.cloneNode(true)
    svgEl.setAttribute('xmlns', 'http://www.w3.org/2000/svg')
    const serializer = new XMLSerializer()
    const svgStr = serializer.serializeToString(svgEl)

    try {
      const res = await API.post('/api/projects', {
        name: projectName,
        svg: svgStr,
      })
      alert('Project saved: ' + res.data.id)
    } catch (err) {
      alert(err.response?.data?.message || 'Save failed')
    }
  }

  function clearCanvas() {
    setStrokes([])
  }

  return (
    <div>
      <div className="controls">
        <label>Stroke width: </label>
        <input type="range" min="1" max="80" value={strokeWidth} onChange={(e) => setStrokeWidth(Number(e.target.value))} />
        <span style={{ marginLeft: 8 }}>{strokeWidth}px</span>

        <label style={{ marginLeft: 12 }}>Color: </label>
        <input type="color" value={strokeColor} onChange={(e) => setStrokeColor(e.target.value)} />

        <input placeholder="Project name" value={projectName} onChange={(e)=>setProjectName(e.target.value)} style={{ marginLeft:12 }} />

        <button onClick={exportSVG}>Export SVG</button>
        <button onClick={saveProject}>Save to Server</button>
        <button onClick={clearCanvas}>Clear</button>
      </div>

      <svg
        ref={svgRef}
        width={900}
        height={500}
        className="svg-canvas"
        onPointerDown={pointerDown}
        style={{ touchAction: 'none' }}
      >
        <rect width="100%" height="100%" fill="#ffffff" />
        {strokes.map((s, i) => (
          <path key={i} d={s.d} stroke={s.color} strokeWidth={s.width} strokeLinecap="round" strokeLinejoin="round" fill="none" />
        ))}
        {current && (
          <path d={pointsToSvgPath(current.points)} stroke={current.color} strokeWidth={current.width} strokeLinecap="round" strokeLinejoin="round" fill="none" />
        )}
      </svg>
    </div>
  )
}
