import React, { useState } from 'react'
import Editor from './components/Editor'
import Login from './pages/Login'
import Register from './pages/Register'

export default function App() {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem('me') || 'null') } catch { return null }
  })

  function onLogin(userData, token) {
    localStorage.setItem('me', JSON.stringify(userData))
    localStorage.setItem('token', token)
    setUser(userData)
  }

  function logout() {
    localStorage.removeItem('me')
    localStorage.removeItem('token')
    setUser(null)
  }

  return (
    <div className="app">
      <div className="header">
        <h2>Kaleam-like Editor (Prototype)</h2>
        <div>
          {user ? (
            <>
              <span style={{marginRight:8}}>مرحبًا، {user.email}</span>
              <button onClick={logout}>Logout</button>
            </>
          ) : (
            <>
              <Login onLogin={onLogin} />
              <Register onLogin={onLogin} />
            </>
          )}
        </div>
      </div>

      <Editor user={user} />
    </div>
  )
}
