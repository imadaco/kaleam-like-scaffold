import React, { useState } from 'react'
import API from '../api'

export default function Register({ onLogin }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  async function submit(e) {
    e.preventDefault()
    try {
      const res = await API.post('/api/auth/register', { email, password })
      const { user, token } = res.data
      onLogin(user, token)
    } catch (err) {
      alert(err.response?.data?.message || 'Register error')
    }
  }

  return (
    <form onSubmit={submit} style={{ display:'inline-block' }}>
      <input placeholder="email" value={email} onChange={e=>setEmail(e.target.value)} />
      <input placeholder="password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
      <button type="submit">Register</button>
    </form>
  )
}
